//
//  MainCell.m
//  BleSerial
//
//  Created by Han.zh on 14-9-30.
//  Copyright (c) 2014年 Han.zhihong. All rights reserved.
//

#import "MainCell.h"

@implementation MainCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
